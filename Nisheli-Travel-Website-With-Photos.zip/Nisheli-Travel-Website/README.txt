NISHELI TRAVEL WEBSITE

This is a mobile-friendly multi-section website built with HTML, CSS and JavaScript.

FILES
- index.html : Main website
- style.css  : Design and responsive layout
- script.js  : Mobile menu and demo review system

IMPORTANT: WHATSAPP
Open index.html and replace BOTH occurrences of:
947XXXXXXXX
with your WhatsApp number in international format, without + or spaces.
Example: 94771234567

HOW TO USE FROM A PHONE
1. Extract this ZIP using a file manager app.
2. Open index.html in a browser to preview it.
3. To publish it free, upload these three files to a hosting service such as GitHub Pages or Netlify.

REVIEWS
The included review form is a front-end demo and saves reviews only on the visitor's device.
For real public reviews, connect the form to Firebase, Supabase, or a Google Form/database.

Brand name: Nisheli Travel
Business experience: Since 2016
Email: nishlitravel@gmail.com


PHOTOS
This version includes a Sri Lanka destination photo gallery and travel imagery. The photos load from online image sources, so an internet connection is needed to view them on the website.
For a fully branded website, you can later replace any photo with your own travel photographs.
